-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: django_pro
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `django_pro`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `django_pro` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `django_pro`;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add user',2,'add_user'),(5,'Can change user',2,'change_user'),(6,'Can delete user',2,'delete_user'),(7,'Can add permission',3,'add_permission'),(8,'Can change permission',3,'change_permission'),(9,'Can delete permission',3,'delete_permission'),(10,'Can add group',4,'add_group'),(11,'Can change group',4,'change_group'),(12,'Can delete group',4,'delete_group'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add users',7,'add_users'),(20,'Can change users',7,'change_users'),(21,'Can delete users',7,'delete_users'),(22,'Can add types',8,'add_types'),(23,'Can change types',8,'change_types'),(24,'Can delete types',8,'delete_types'),(25,'Can add goods',9,'add_goods'),(26,'Can change goods',9,'change_goods'),(27,'Can delete goods',9,'delete_goods');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(4,'auth','group'),(3,'auth','permission'),(2,'auth','user'),(5,'contenttypes','contenttype'),(9,'myadmin','goods'),(8,'myadmin','types'),(7,'myadmin','users'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2018-04-12 15:49:01.661820'),(2,'auth','0001_initial','2018-04-12 15:49:01.967604'),(3,'admin','0001_initial','2018-04-12 15:49:02.034585'),(4,'admin','0002_logentry_remove_auto_add','2018-04-12 15:49:02.054683'),(5,'contenttypes','0002_remove_content_type_name','2018-04-12 15:49:02.118696'),(6,'auth','0002_alter_permission_name_max_length','2018-04-12 15:49:02.148248'),(7,'auth','0003_alter_user_email_max_length','2018-04-12 15:49:02.202413'),(8,'auth','0004_alter_user_username_opts','2018-04-12 15:49:02.214561'),(9,'auth','0005_alter_user_last_login_null','2018-04-12 15:49:02.243239'),(10,'auth','0006_require_contenttypes_0002','2018-04-12 15:49:02.248073'),(11,'auth','0007_alter_validators_add_error_messages','2018-04-12 15:49:02.260212'),(12,'auth','0008_alter_user_username_max_length','2018-04-12 15:49:02.323057'),(13,'myadmin','0001_initial','2018-04-12 15:49:02.349543'),(14,'myadmin','0002_user_pic','2018-04-12 15:49:02.380274'),(15,'myadmin','0003_auto_20180411_0751','2018-04-12 15:49:02.404396'),(16,'myadmin','0004_auto_20180412_1410','2018-04-12 15:49:02.421273'),(17,'myadmin','0005_users_delete_data','2018-04-12 15:49:02.451056'),(18,'sessions','0001_initial','2018-04-12 15:49:02.469893'),(19,'myadmin','0006_auto_20180412_2354','2018-04-12 15:54:48.902176'),(20,'myadmin','0007_auto_20180412_2357','2018-04-12 15:57:17.527979'),(21,'myadmin','0008_auto_20180413_1854','2018-04-13 10:54:49.607436');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('2zpjs2fjine0fpfy55lugzhl1isi3vrt','ZDUwYzM5ODMwYjFiMTc0MGY1YzBkNTIzYzcxM2FkNTJiMWFiZjczYzp7ImNhcnQiOnsiNiI6eyJwcmljZSI6OTk5MC4wLCJwaWMiOiIvc3RhdGljL215YWRtaW4vZ29vZHNfaW1hZ2VzL2pzanBwWk5ZMTUyMzg2MDMwMC4xMzcwNTUuanBnIiwibnVtIjoxLCJpZCI6NiwidGl0bGUiOiJpcGhvbmU2In19fQ==','2018-04-22 13:40:59.866920'),('ufov2065hqrn5pladhvb1bh945ft33gu','OGI1ZmY1ZWZiMWRjZGViYmQ3ZDhiYTBmYzE3ZDliYjAwNjIxYzU4Mzp7ImxvZ2luX3N0YXR1cyI6dHJ1ZSwibG9naW5fdXNlcnMiOnsidXNlcl9pZCI6MiwidXNlcm5hbWUiOiJcdTU5ODJcdTY4YTZkcmVhbXpzeSJ9LCJvcmRlcl9hZGQiOlt7InByaWNlIjozOTkuMCwibnVtIjoxLCJpZCI6OCwicGljIjoiL3N0YXRpYy9teWFkbWluL2dvb2RzX2ltYWdlcy9DaEllUE9ldDE1MjM4ODM3NjEuNjExMzk4LmpwZyIsInRpdGxlIjoiXHU3OTVlXHU3OWQ4XHU2ZDc3XHU1N2RmNCAsIFx1NWUyNlx1NGY2MFx1OGQ3MFx1OGZkYlx1NjNhMlx1OTY2OVx1NzY4NFx1NGU1MFx1OGRhMyJ9LHsicHJpY2UiOjEwLjAsIm51bSI6MywiaWQiOjIsInBpYyI6Ii9zdGF0aWMvbXlhZG1pbi9nb29kc19pbWFnZXMvSUdsOXY1WmYxNTIzNjkzOTY2LjE1MjY3ODUuanBnIiwidGl0bGUiOiJcdTdiMWJcdTViNTAifV0sImNhcnQiOnsiOCI6eyJwcmljZSI6Mzk5LjAsIm51bSI6MSwiaWQiOjgsInBpYyI6Ii9zdGF0aWMvbXlhZG1pbi9nb29kc19pbWFnZXMvQ2hJZVBPZXQxNTIzODgzNzYxLjYxMTM5OC5qcGciLCJ0aXRsZSI6Ilx1Nzk1ZVx1NzlkOFx1NmQ3N1x1NTdkZjQgLCBcdTVlMjZcdTRmNjBcdThkNzBcdThmZGJcdTYzYTJcdTk2NjlcdTc2ODRcdTRlNTBcdThkYTMifSwiMSI6eyJwcmljZSI6Mzk5LjAsIm51bSI6MiwiaWQiOjEsInBpYyI6Ii9zdGF0aWMvbXlhZG1pbi9nb29kc19pbWFnZXMvMTUyMzY5MTkzMS44MjgxMTYuanBnIiwidGl0bGUiOiIxMjMxMjNcdTU1NDZcdTU0YzFcdTU0MGQifSwiMTAiOnsicHJpY2UiOjI5OS4wLCJudW0iOjEsImlkIjoxMCwicGljIjoiL3N0YXRpYy9teWFkbWluL2dvb2RzX2ltYWdlcy9lTzlVQ0Z3VDE1MjM4ODUwMzIuODM2NTg4Ni5wbmciLCJ0aXRsZSI6Ilx1ODRkZFx1NzI1OVx1NjI0Ylx1NzNhZiJ9LCIyIjp7InByaWNlIjoxMC4wLCJudW0iOjMsImlkIjoyLCJwaWMiOiIvc3RhdGljL215YWRtaW4vZ29vZHNfaW1hZ2VzL0lHbDl2NVpmMTUyMzY5Mzk2Ni4xNTI2Nzg1LmpwZyIsInRpdGxlIjoiXHU3YjFiXHU1YjUwIn19fQ==','2018-04-22 14:00:46.230620');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_goods`
--

DROP TABLE IF EXISTS `myadmin_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `storage` int(11) NOT NULL,
  `pic` varchar(64) NOT NULL,
  `info` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `addmin` datetime(6) NOT NULL,
  `typeid_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `myadmin_goods_typeid_id_a0810d57_fk_myadmin_types_id` (`typeid_id`),
  CONSTRAINT `myadmin_goods_typeid_id_a0810d57_fk_myadmin_types_id` FOREIGN KEY (`typeid_id`) REFERENCES `myadmin_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_goods`
--

LOCK TABLES `myadmin_goods` WRITE;
/*!40000 ALTER TABLE `myadmin_goods` DISABLE KEYS */;
INSERT INTO `myadmin_goods` VALUES (1,'123123商品名',399.00,999,'/static/myadmin/goods_images/1523691931.828116.jpg','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;123123商品名\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p><img src=\"/static/media/article/20180415/20180415182819199.jpg\" title=\"20180415/20180415182819199.jpg\" alt=\"20180415/20180415182819199.jpg\" width=\"427\" height=\"395\" style=\"width: 427px; height: 395px;\"/></p>',1,'2018-04-14 07:45:31.858540',5),(2,'笛子',10.00,182,'/static/myadmin/goods_images/IGl9v5Zf1523693966.1526785.jpg','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;笛子\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>',1,'2018-04-14 08:19:26.181431',4),(3,'白色西服',19000.00,99,'/static/myadmin/goods_images/Dxx1oCYG1523694478.3959644.jpg','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;白色西服\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p><img src=\"/static/media/article/20180414/20180414211436608.jpg\" title=\"20180414/20180414211436608.jpg\" alt=\"20180414/20180414211436608.jpg\" width=\"466\" height=\"478\" style=\"width: 466px; height: 478px;\"/></p>',1,'2018-04-14 08:27:58.426753',5),(4,'连衣裙',99.00,128,'/static/myadmin/goods_images/WzWcHrq11523715536.9549606.jpg','<p>连衣裙女生, 图片女生</p><p><img src=\"/static/media/article/20180414/20180414210333707.jpg\" title=\"20180414/20180414210333707.jpg\" alt=\"20180414/20180414210333707.jpg\"/></p>',1,'2018-04-14 10:06:34.722709',5),(6,'iphone6',9990.00,9999,'/static/myadmin/goods_images/jsjppZNY1523860300.137055.jpg','',2,'2018-04-16 06:31:40.138807',6),(7,'虎皮裙',800000.00,12,'/static/myadmin/goods_images/S3TOdxj91523880595.5461733.jpg','<p><img src=\"/static/media/article/20180416/20180416200953837.jpg\" title=\"20180416/20180416200953837.jpg\" alt=\"20180416/20180416200953837.jpg\"/></p>',1,'2018-04-16 12:09:55.547142',8),(8,'神秘海域4 , 带你走进探险的乐趣',399.00,99999,'/static/myadmin/goods_images/ChIePOet1523883761.611398.jpg','<p>神秘海域4 , 带你走进探险的乐趣</p>',2,'2018-04-16 13:02:41.614312',7),(9,'钢琴',150000.00,34,'/static/myadmin/goods_images/dlC2ODDA1523884663.6372116.jpg','<p>钢琴</p>',2,'2018-04-16 13:17:43.638657',4),(10,'蓝牙手环',299.00,299,'/static/myadmin/goods_images/eO9UCFwT1523885032.8365886.png','<p>123</p>',2,'2018-04-16 13:23:52.837473',6),(11,'魅族手机金色',1990.00,900,'/static/myadmin/goods_images/gI1MX2jG1523885196.1174948.jpg','<p>123</p>',1,'2018-04-16 13:26:36.118576',6),(12,'生化危机6',399.00,999999,'/static/myadmin/goods_images/U02Pj8Av1523885422.6395748.jpeg','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;商品 介绍:\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p><img src=\"/static/media/article/20180416/20180416213017737.jpeg\" title=\"20180416/20180416213017737.jpeg\" alt=\"20180416/20180416213017737.jpeg\"/></p>',2,'2018-04-16 13:30:22.640875',7),(13,'女士皮裤',1314.00,99,'/static/myadmin/goods_images/Yd5B1wtm1523885502.9067385.jpg','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;商品 介绍:\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p><br/></p>',2,'2018-04-16 13:31:42.907605',8),(14,'魅族 PRO 7',2880.00,1000,'/static/myadmin/goods_images/rt9e4mwi1523885911.5814772.png','<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;商品 介绍:\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>',2,'2018-04-16 13:38:31.582626',6);
/*!40000 ALTER TABLE `myadmin_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_types`
--

DROP TABLE IF EXISTS `myadmin_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `pid` int(11) NOT NULL,
  `path` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_types`
--

LOCK TABLES `myadmin_types` WRITE;
/*!40000 ALTER TABLE `myadmin_types` DISABLE KEYS */;
INSERT INTO `myadmin_types` VALUES (1,'服装',0,'0,'),(2,'电子',0,'0,'),(3,'娱乐',0,'0,'),(4,'乐器',3,'0,3,'),(5,'男装',1,'0,1,'),(6,'手机',2,'0,2,'),(7,'游戏',3,'0,3,'),(8,'女装',1,'0,1,');
/*!40000 ALTER TABLE `myadmin_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_users`
--

DROP TABLE IF EXISTS `myadmin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(128) NOT NULL,
  `sex` varchar(3) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(64) NOT NULL,
  `status` int(11) NOT NULL,
  `addtime` datetime(6) NOT NULL,
  `pic` varchar(128) NOT NULL,
  `delete_data` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_users`
--

LOCK TABLES `myadmin_users` WRITE;
/*!40000 ALTER TABLE `myadmin_users` DISABLE KEYS */;
INSERT INTO `myadmin_users` VALUES (1,'ghs','123123123123','0',12323,'123123','123123','123123123@qq.com',0,'2018-04-12 03:50:34.204124','/static/public/pics/12312312123+1523505034.2021792.jpg','0'),(2,'如梦dreamzsy','pbkdf2_sha256$36000$ZGVg09DaKCiB$Tp2XjvRVcZkxyLSHyOb0xEC4vrIDcbedm3tosh5R5vw=','1',18,'dreamzsy@zsy.com','123123','dreamzsy@zsy.com',1,'2018-04-12 04:02:53.736359','/static/public/pics/如梦dreamzsy+1523605872.7220674.jpg','1'),(3,'zsy','pbkdf2_sha256$36000$Kp5a6It5dblj$01X4/ECauuCPAriCXC24/RPexTn9XGLMM9iXgYuyark=','1',18,'兄弟连','17777777777','17777777777@163.com',2,'2018-04-12 05:28:44.949693','/static/public/pics/zsy+1523510924.9352746.jpg','1'),(4,'abc132','pbkdf2_sha256$36000$UUOkWv7BzYax$XQ+FbofR8De9Jbn+cGy81Fjh1n7OgwBBhyGTJRRTbYU=','1',132,'abc123','123123','123123123@qq.com',1,'2018-04-12 06:02:38.433269','/static/public/pics/abc132+1523512958.4314368.jpg','0'),(5,'sxxhq','pbkdf2_sha256$36000$YkO51mO4RcQq$WO07F6ueqJ0IDsj4cNqq9sG20xiyCaR3bpqb0zqwCkU=','1',18,'123456','12345678901','123123123@qq.com',1,'2018-04-12 06:10:18.705298','/static/public/pics/user.png','1'),(6,'root6','123467','1',1,'root6','66666666666','root6',1,'2018-04-12 12:14:20.523884','/static/public/pics/user.png','1'),(7,'root7','123467','1',1,'root7','77777777777','root7',1,'2018-04-12 12:16:31.775869','/static/public/pics/user.png','0'),(8,'root8','123467','1',1,'root8','88888888888','root8',1,'2018-04-12 12:16:31.781333','/static/public/pics/user.png','1'),(9,'root9','123467','0',1,'root9','99999999999','root9',1,'2018-04-12 12:16:31.783786','/static/public/pics/user.png','0'),(10,'root10','123467','0',1,'root10','1010101010','root10',1,'2018-04-12 12:16:31.786524','/static/public/pics/user.png','0'),(11,'root11','123467','0',1,'root11','11111111111','root11',1,'2018-04-12 12:16:31.789867','/static/public/pics/user.png','1'),(12,'root12','123467','0',1,'root12','21212121212','root12',1,'2018-04-12 12:16:31.796186','/static/public/pics/user.png','1'),(13,'root13','123467','0',1,'root13','31313131313','root13',1,'2018-04-12 12:16:31.799428','/static/public/pics/user.png','1'),(14,'root14','123467','0',1,'root14','41414141414','root14',1,'2018-04-12 12:16:31.802780','/static/public/pics/user.png','1'),(15,'root15','123467','1',1,'root15','51515151515','root15',1,'2018-04-12 12:16:31.806175','/static/public/pics/user.png','1'),(16,'root16','123467','1',1,'root16','61616161616','root16',1,'2018-04-12 12:16:31.810226','/static/public/pics/user.png','1'),(17,'root17','123467','1',1,'root17','71717171717','root17',1,'2018-04-12 12:16:31.815699','/static/public/pics/user.png','1'),(18,'root18','123467','1',1,'root18','81818181818','root18',1,'2018-04-12 12:16:31.818638','/static/public/pics/user.png','1'),(19,'root19','123467','1',1,'root19','91919191919','root19',1,'2018-04-12 12:16:31.822285','/static/public/pics/user.png','1'),(20,'root20','123467','1',1,'root20','2020202020','root20',1,'2018-04-12 12:16:31.826807','/static/public/pics/user.png','1'),(21,'root21','123467','1',1,'root21','12121212121','root21',1,'2018-04-12 12:16:31.830596','/static/public/pics/user.png','1'),(22,'root22','123467','1',1,'root22','22222222222','root22',1,'2018-04-12 12:16:31.835471','/static/public/pics/user.png','1'),(23,'root23','123467','1',1,'root23','32323232323','root23',1,'2018-04-12 12:16:31.838994','/static/public/pics/user.png','1'),(24,'root24','123467','1',1,'root24','42424242424','root24',1,'2018-04-12 12:16:31.843868','/static/public/pics/user.png','1'),(25,'root25','123467','1',1,'root25','52525252525','root25',1,'2018-04-12 12:16:31.849572','/static/public/pics/user.png','1'),(26,'root26','123467','1',1,'root26','62626262626','root26',1,'2018-04-12 12:16:31.851313','/static/public/pics/user.png','1'),(27,'root27','123467','1',1,'root27','72727272727','root27',1,'2018-04-12 12:16:31.853218','/static/public/pics/user.png','1'),(28,'root28','123467','1',1,'root28','82828282828','root28',1,'2018-04-12 12:16:31.856306','/static/public/pics/user.png','1'),(29,'root29','123467','1',1,'root29','92929292929','root29',1,'2018-04-12 12:16:31.861090','/static/public/pics/user.png','1'),(30,'root30','123467','1',1,'root30','3030303030','root30',0,'2018-04-12 12:16:31.864803','/static/public/pics/user.png','1'),(31,'root31','123467','1',1,'root31','13131313131','root31',0,'2018-04-12 12:16:31.866989','/static/public/pics/user.png','1'),(32,'root32','123467','1',1,'root32','23232323232','root32',0,'2018-04-12 12:16:31.869393','/static/public/pics/user.png','1'),(33,'root33','123467','1',1,'root33','33333333333','root33',0,'2018-04-12 12:16:31.872374','/static/public/pics/user.png','1'),(34,'root34','123467','1',1,'root34','43434343434','root34',0,'2018-04-12 12:16:31.876508','/static/public/pics/user.png','1'),(35,'root35','123467','1',1,'root35','53535353535','root35',0,'2018-04-12 12:16:31.881637','/static/public/pics/user.png','1'),(36,'root36','123467','1',1,'root36','63636363636','root36',1,'2018-04-12 12:16:31.884562','/static/public/pics/user.png','1'),(37,'root37','123467','1',1,'root37','73737373737','root37',1,'2018-04-12 12:16:31.888076','/static/public/pics/user.png','1'),(38,'root38','123467','1',1,'root38','83838383838','root38',1,'2018-04-12 12:16:31.895745','/static/public/pics/user.png','1'),(39,'root39','123467','1',1,'root39','93939393939','root39',1,'2018-04-12 12:16:31.899692','/static/public/pics/user.png','1'),(40,'root40','123467','1',1,'root40','4040404040','root40',1,'2018-04-12 12:16:31.902686','/static/public/pics/user.png','1'),(41,'root41','123467','0',1,'root41','14141414141','root41',1,'2018-04-12 12:16:31.905400','/static/public/pics/user.png','1'),(42,'root42','123467','0',46,'root42','4242424242','root42',1,'2018-04-12 12:16:31.911367','/static/public/pics/user.png','1'),(43,'root43','123467','0',46,'root43','4343434343','root43',1,'2018-04-12 12:16:31.914407','/static/public/pics/user.png','1'),(44,'root44','123467','0',46,'root44','4444444444','root44',1,'2018-04-12 12:16:31.917742','/static/public/pics/user.png','1'),(45,'root45','123467','0',46,'root45','4545454545','root45',1,'2018-04-12 12:16:31.920364','/static/public/pics/user.png','1'),(46,'root46','123467','0',46,'root46','4646464646','root46',1,'2018-04-12 12:16:31.923737','/static/public/pics/user.png','1'),(47,'root47','123467','0',46,'root47','4747474747','root47',1,'2018-04-12 12:16:31.927718','/static/public/pics/user.png','1'),(48,'root48','123467','0',46,'root48','4848484848','root48',1,'2018-04-12 12:16:31.937799','/static/public/pics/user.png','1'),(49,'root49','123467','0',46,'root49','4949494949','root49',1,'2018-04-12 12:16:31.942827','/static/public/pics/user.png','1'),(50,'root50','123467','0',46,'root50','5050505050','root50',1,'2018-04-12 12:16:31.946603','/static/public/pics/user.png','1'),(51,'root51','123467','0',46,'root51','5151515151','root51',1,'2018-04-12 12:16:31.949925','/static/public/pics/user.png','1'),(52,'root52','123467','0',46,'root52','5252525252','root52',1,'2018-04-12 12:16:31.951913','/static/public/pics/user.png','1'),(53,'root53','123467','0',46,'root53','5353535353','root53',1,'2018-04-12 12:16:31.953856','/static/public/pics/user.png','1'),(54,'root54','123467','0',46,'root54','5454545454','root54',1,'2018-04-12 12:16:31.955650','/static/public/pics/user.png','1'),(55,'root55','123467','0',46,'root55','5555555555','root55',1,'2018-04-12 12:16:31.958253','/static/public/pics/user.png','1'),(56,'root56','123467','0',46,'root56','5656565656','root56',1,'2018-04-12 12:16:31.962339','/static/public/pics/user.png','1'),(57,'root57','123467','0',46,'root57','5757575757','root57',1,'2018-04-12 12:16:31.964307','/static/public/pics/user.png','1'),(58,'root58','123467','0',46,'root58','5858585858','root58',1,'2018-04-12 12:16:31.967813','/static/public/pics/user.png','1'),(59,'root59','123467','0',46,'root59','5959595959','root59',1,'2018-04-12 12:16:31.970880','/static/public/pics/user.png','1'),(60,'root60','123467','0',46,'root60','6060606060','root60',0,'2018-04-12 12:16:31.973399','/static/public/pics/user.png','1'),(61,'root61','123467','1',46,'root61','6161616161','root61',0,'2018-04-12 12:16:31.975000','/static/public/pics/user.png','1'),(62,'root62','123467','1',46,'root62','6262626262','root62',0,'2018-04-12 12:16:31.976513','/static/public/pics/user.png','1'),(63,'root63','123467','1',46,'root63','6363636363','root63',0,'2018-04-12 12:16:31.977989','/static/public/pics/user.png','1'),(64,'root64','123467','1',46,'root64','6464646464','root64',0,'2018-04-12 12:16:31.980089','/static/public/pics/user.png','1'),(65,'root65','123467','1',1,'root65','6565656565','root65',0,'2018-04-12 12:16:31.985088','/static/public/pics/user.png','1'),(66,'root66','123467','1',1,'root66','6666666666','root66',1,'2018-04-12 12:16:31.987051','/static/public/pics/user.png','1'),(67,'root67','123467','1',1,'root67','6767676767','root67',1,'2018-04-12 12:16:31.988922','/static/public/pics/user.png','1'),(68,'root68','123467','1',1,'root68','6868686868','root68',1,'2018-04-12 12:16:31.991864','/static/public/pics/user.png','1'),(69,'root69','123467','1',1,'root69','6969696969','root69',1,'2018-04-12 12:16:31.993859','/static/public/pics/user.png','1'),(70,'root70','123467','1',1,'root70','7070707070','root70',1,'2018-04-12 12:16:31.996148','/static/public/pics/user.png','1'),(71,'root71','123467','1',1,'root71','7171717171','root71',1,'2018-04-12 12:16:31.998983','/static/public/pics/user.png','1'),(72,'root72','123467','0',1,'root72','7272727272','root72',1,'2018-04-12 12:16:32.001847','/static/public/pics/user.png','1'),(73,'root73','123467','0',1,'root73','7373737373','root73',1,'2018-04-12 12:16:32.003922','/static/public/pics/user.png','1'),(74,'root74','123467','0',1,'root74','7474747474','root74',1,'2018-04-12 12:16:32.005946','/static/public/pics/user.png','1'),(75,'root75','123467','0',1,'root75','7575757575','root75',1,'2018-04-12 12:16:32.008329','/static/public/pics/user.png','1'),(76,'root76','123467','0',1,'root76','7676767676','root76',1,'2018-04-12 12:16:32.010824','/static/public/pics/user.png','1'),(77,'root77','123467','0',1,'root77','7777777777','root77',1,'2018-04-12 12:16:32.013553','/static/public/pics/user.png','1'),(78,'root78','123467','0',1,'root78','7878787878','root78',1,'2018-04-12 12:16:32.016118','/static/public/pics/user.png','1'),(79,'root79','123467','0',1,'root79','7979797979','root79',1,'2018-04-12 12:16:32.019034','/static/public/pics/user.png','1'),(80,'root80','123467','1',1,'root80','8080808080','root80',1,'2018-04-12 12:16:32.020967','/static/public/pics/user.png','1'),(81,'root81','123467','1',1,'root81','8181818181','root81',1,'2018-04-12 12:16:32.022255','/static/public/pics/user.png','1'),(82,'root82','123467','1',1,'root82','8282828282','root82',1,'2018-04-12 12:16:32.023955','/static/public/pics/user.png','1'),(83,'root83','123467','1',1,'root83','8383838383','root83',1,'2018-04-12 12:16:32.027088','/static/public/pics/user.png','1'),(84,'root84','123467','1',1,'root84','8484848484','root84',1,'2018-04-12 12:16:32.029220','/static/public/pics/user.png','1'),(85,'root85','123467','1',1,'root85','8585858585','root85',1,'2018-04-12 12:16:32.031339','/static/public/pics/user.png','1'),(86,'root86','123467','1',1,'root86','8686868686','root86',1,'2018-04-12 12:16:32.033003','/static/public/pics/user.png','1'),(87,'root87','123467','1',1,'root87','8787878787','root87',1,'2018-04-12 12:16:32.035810','/static/public/pics/user.png','1'),(88,'root88','123467','1',1,'root88','8888888888','root88',1,'2018-04-12 12:16:32.039218','/static/public/pics/user.png','1'),(89,'root89','123467','1',1,'root89','8989898989','root89',1,'2018-04-12 12:16:32.042534','/static/public/pics/user.png','1'),(90,'root90','123467','1',1,'root90','9090909090','root90',1,'2018-04-12 12:16:32.043889','/static/public/pics/user.png','1'),(91,'root91','123467','1',1,'root91','9191919191','root91',1,'2018-04-12 12:16:32.045130','/static/public/pics/user.png','1'),(92,'root92','123467','0',1,'root92','9292929292','root92',1,'2018-04-12 12:16:32.046468','/static/public/pics/user.png','1'),(93,'root93','123467','0',1,'root93','9393939393','root93',1,'2018-04-12 12:16:32.048803','/static/public/pics/user.png','1'),(94,'root94','123467','0',1,'root94','9494949494','root94',1,'2018-04-12 12:16:32.050400','/static/public/pics/user.png','1'),(95,'root95','123467','0',1,'root95','9595959595','root95',1,'2018-04-12 12:16:32.051903','/static/public/pics/user.png','1'),(96,'root96','123467','0',1,'root96','9696969696','root96',1,'2018-04-12 12:16:32.053891','/static/public/pics/user.png','1'),(97,'root97','123467','0',1,'root97','9797979797','root97',1,'2018-04-12 12:16:32.055395','/static/public/pics/user.png','1'),(98,'root98','123467','0',1,'root98','9898989898','root98',1,'2018-04-12 12:16:32.057006','/static/public/pics/user.png','1'),(99,'root99','123467','0',1,'root99','9999999999','root99',1,'2018-04-12 12:16:32.059156','/static/public/pics/user.png','1'),(100,'root100','123467','0',1,'root100','100100100','root100',1,'2018-04-12 12:16:32.062042','/static/public/pics/user.png','1'),(101,'root101','123467','0',1,'root101','1101101101','root101',1,'2018-04-12 12:16:32.064025','/static/public/pics/user.png','1'),(102,'root102','123467','0',1,'root102','2102102102','root102',1,'2018-04-12 12:16:32.066206','/static/public/pics/user.png','1'),(103,'root103','123467','0',1,'root103','3103103103','root103',1,'2018-04-12 12:16:32.068948','/static/public/pics/user.png','1'),(104,'root104','123467','0',1,'root104','4104104104','root104',1,'2018-04-12 12:16:32.074836','/static/public/pics/user.png','1'),(105,'root105','123467','0',1,'root105','5105105105','root105',1,'2018-04-12 12:16:32.077893','/static/public/pics/user.png','1'),(106,'root106','123467','0',1,'root106','6106106106','root106',1,'2018-04-12 12:16:32.079836','/static/public/pics/user.png','1'),(107,'root107','123467','0',1,'root107','7107107107','root107',1,'2018-04-12 12:16:32.082787','/static/public/pics/user.png','1'),(108,'root108','123467','0',1,'root108','8108108108','root108',1,'2018-04-12 12:16:32.084595','/static/public/pics/user.png','1'),(109,'root109','123467','0',1,'root109','9109109109','root109',1,'2018-04-12 12:16:32.087209','/static/public/pics/user.png','1'),(110,'root110','123467','0',1,'root110','110110110','root110',1,'2018-04-12 12:16:32.090402','/static/public/pics/user.png','1'),(111,'root111','123467','1',1,'root111','1111111111','root111',1,'2018-04-12 12:16:32.093795','/static/public/pics/user.png','1'),(112,'root112','123467','1',1,'root112','2112112112','root112',1,'2018-04-12 12:16:32.095665','/static/public/pics/user.png','1'),(113,'root113','123467','1',1,'root113','3113113113','root113',1,'2018-04-12 12:16:32.098139','/static/public/pics/user.png','1'),(114,'root114','123467','1',1,'root114','4114114114','root114',1,'2018-04-12 12:16:32.099838','/static/public/pics/user.png','1'),(115,'root115','123467','1',1,'root115','5115115115','root115',1,'2018-04-12 12:16:32.101373','/static/public/pics/user.png','1'),(116,'root116','123467','1',1,'root116','6116116116','root116',1,'2018-04-12 12:16:32.102898','/static/public/pics/user.png','1'),(117,'root117','123467','1',18,'root117','17117117117','root117',1,'2018-04-12 12:16:32.104462','/static/public/pics/user.png','1'),(118,'root118','123467','1',18,'root118','18118118118','root118',1,'2018-04-12 12:16:32.107688','/static/public/pics/user.png','1'),(119,'root119','123467','1',18,'root119','19119119119','root119',1,'2018-04-12 12:16:32.109911','/static/public/pics/user.png','1'),(120,'root120','123467','1',18,'root120','20120120120','root120',1,'2018-04-12 12:16:32.112310','/static/public/pics/user.png','1'),(121,'root121','123467','1',18,'root121','21121121121','root121',1,'2018-04-12 12:16:32.114218','/static/public/pics/user.png','1'),(122,'root122','123467','1',18,'root122','22122122122','root122',1,'2018-04-12 12:16:32.116633','/static/public/pics/user.png','1'),(123,'root123','123467','1',18,'root123','23123123123','root123',1,'2018-04-12 12:16:32.119872','/static/public/pics/user.png','1'),(124,'root124','123467','1',18,'root124','24124124124','root124',1,'2018-04-12 12:16:32.122782','/static/public/pics/user.png','1'),(125,'root125','123467','1',18,'root125','25125125125','root125',1,'2018-04-12 12:16:32.125267','/static/public/pics/user.png','1'),(126,'root126','123467','1',18,'root126','26126126126','root126',1,'2018-04-12 12:16:32.127525','/static/public/pics/user.png','1'),(127,'root127','123467','1',18,'root127','27127127127','root127',1,'2018-04-12 12:16:32.129032','/static/public/pics/user.png','1'),(128,'root128','123467','1',18,'root128','28128128128','root128',1,'2018-04-12 12:16:32.130971','/static/public/pics/user.png','1'),(129,'root129','123467','1',18,'root129','29129129129','root129',1,'2018-04-12 12:16:32.134799','/static/public/pics/user.png','1'),(130,'root130','123467','1',18,'root130','30130130130','root130',1,'2018-04-12 12:16:32.137746','/static/public/pics/user.png','1'),(131,'root131','123467','1',18,'root131','31131131131','root131',1,'2018-04-12 12:16:32.139245','/static/public/pics/user.png','1'),(132,'root132','123467','1',18,'root132','32132132132','root132',1,'2018-04-12 12:16:32.140965','/static/public/pics/user.png','1'),(133,'root133','123467','1',18,'root133','33133133133','root133',1,'2018-04-12 12:16:32.142816','/static/public/pics/user.png','1'),(134,'root134','123467','1',18,'root134','34134134134','root134',1,'2018-04-12 12:16:32.145119','/static/public/pics/user.png','1'),(135,'root135','123467','1',1,'root135','35135135135','root135',1,'2018-04-12 12:16:32.146631','/static/public/pics/user.png','1'),(136,'root136','123467','1',1,'root136','36136136136','root136',1,'2018-04-12 12:16:32.148760','/static/public/pics/user.png','1'),(137,'root137','123467','1',1,'root137','37137137137','root137',1,'2018-04-12 12:16:32.152287','/static/public/pics/user.png','1'),(138,'root138','123467','1',1,'root138','38138138138','root138',1,'2018-04-12 12:16:32.154752','/static/public/pics/user.png','1'),(139,'root139','123467','1',1,'root139','39139139139','root139',1,'2018-04-12 12:16:32.157271','/static/public/pics/user.png','1'),(140,'root140','123467','1',1,'root140','40140140140','root140',1,'2018-04-12 12:16:32.159367','/static/public/pics/user.png','1'),(141,'root141','123467','1',1,'root141','41141141141','root141',1,'2018-04-12 12:16:32.161839','/static/public/pics/user.png','1'),(142,'root142','123467','1',1,'root142','42142142142','root142',1,'2018-04-12 12:16:32.165300','/static/public/pics/user.png','1'),(143,'root143','123467','1',1,'root143','43143143143','root143',1,'2018-04-12 12:16:32.167687','/static/public/pics/user.png','1'),(144,'root144','123467','1',1,'root144','44144144144','root144',1,'2018-04-12 12:16:32.169748','/static/public/pics/user.png','1'),(145,'root145','123467','1',1,'root145','45145145145','root145',1,'2018-04-12 12:16:32.172936','/static/public/pics/user.png','1'),(146,'root146','123467','1',1,'root146','46146146146','root146',1,'2018-04-12 12:16:32.177891','/static/public/pics/user.png','1'),(147,'root147','123467','1',1,'root147','47147147147','root147',1,'2018-04-12 12:16:32.180270','/static/public/pics/user.png','1'),(148,'root148','123467','1',1,'root148','48148148148','root148',1,'2018-04-12 12:16:32.184860','/static/public/pics/user.png','1'),(149,'root149','123467','1',1,'root149','49149149149','root149',1,'2018-04-12 12:16:32.186897','/static/public/pics/user.png','1'),(150,'root150','123467','1',1,'root150','50150150150','root150',1,'2018-04-12 12:16:32.189505','/static/public/pics/user.png','1'),(151,'root151','123467','1',1,'root151','51151151151','root151',1,'2018-04-12 12:16:32.192747','/static/public/pics/user.png','1'),(152,'root152','123467','1',1,'root152','52152152152','root152',1,'2018-04-12 12:16:32.194349','/static/public/pics/user.png','1'),(153,'root153','123467','1',1,'root153','53153153153','root153',1,'2018-04-12 12:16:32.197394','/static/public/pics/user.png','1'),(154,'root154','123467','1',1,'root154','54154154154','root154',1,'2018-04-12 12:16:32.200579','/static/public/pics/user.png','1'),(155,'root155','123467','1',1,'root155','55155155155','root155',1,'2018-04-12 12:16:32.203097','/static/public/pics/user.png','1'),(156,'root156','123467','1',1,'root156','56156156156','root156',1,'2018-04-12 12:16:32.205113','/static/public/pics/user.png','1'),(157,'root157','123467','1',1,'root157','57157157157','root157',1,'2018-04-12 12:16:32.207306','/static/public/pics/user.png','1'),(158,'root158','123467','1',1,'root158','58158158158','root158',1,'2018-04-12 12:16:32.211061','/static/public/pics/user.png','1'),(159,'root159','123467','1',1,'root159','59159159159','root159',1,'2018-04-12 12:16:32.213121','/static/public/pics/user.png','1'),(160,'root160','123467','1',1,'root160','60160160160','root160',1,'2018-04-12 12:16:32.216023','/static/public/pics/user.png','1'),(161,'root161','123467','1',1,'root161','61161161161','root161',1,'2018-04-12 12:16:32.217645','/static/public/pics/user.png','1'),(162,'root162','123467','1',1,'root162','62162162162','root162',1,'2018-04-12 12:16:32.219244','/static/public/pics/user.png','1'),(163,'root163','123467','1',1,'root163','63163163163','root163',1,'2018-04-12 12:16:32.223094','/static/public/pics/user.png','1'),(164,'root164','123467','1',1,'root164','64164164164','root164',1,'2018-04-12 12:16:32.225455','/static/public/pics/user.png','1'),(165,'root165','123467','1',1,'root165','65165165165','root165',1,'2018-04-12 12:16:32.227714','/static/public/pics/user.png','1'),(166,'root166','123467','1',1,'root166','66166166166','root166',1,'2018-04-12 12:16:32.230764','/static/public/pics/user.png','1'),(167,'root167','123467','1',1,'root167','67167167167','root167',1,'2018-04-12 12:16:32.234817','/static/public/pics/user.png','1'),(168,'root168','123467','1',1,'root168','68168168168','root168',1,'2018-04-12 12:16:32.238034','/static/public/pics/user.png','1'),(169,'root169','123467','1',1,'root169','69169169169','root169',1,'2018-04-12 12:16:32.241501','/static/public/pics/user.png','1'),(170,'root170','123467','1',1,'root170','70170170170','root170',1,'2018-04-12 12:16:32.243708','/static/public/pics/user.png','1'),(171,'root171','123467','1',1,'root171','71171171171','root171',1,'2018-04-12 12:16:32.245363','/static/public/pics/user.png','1'),(172,'root172','123467','1',1,'root172','72172172172','root172',1,'2018-04-12 12:16:32.246763','/static/public/pics/user.png','1'),(173,'root173','123467','1',1,'root173','73173173173','root173',1,'2018-04-12 12:16:32.249169','/static/public/pics/user.png','1'),(174,'root174','123467','1',1,'root174','74174174174','root174',1,'2018-04-12 12:16:32.251245','/static/public/pics/user.png','1'),(175,'root175','123467','1',1,'root175','75175175175','root175',1,'2018-04-12 12:16:32.253290','/static/public/pics/user.png','1'),(176,'root176','123467','1',1,'root176','76176176176','root176',1,'2018-04-12 12:16:32.255736','/static/public/pics/user.png','1'),(177,'root177','123467','1',23,'root177','77177177177','root177',1,'2018-04-12 12:16:32.258863','/static/public/pics/user.png','1'),(178,'root178','123467','1',23,'root178','78178178178','root178',1,'2018-04-12 12:16:32.261386','/static/public/pics/user.png','1'),(179,'root179','123467','1',23,'root179','79179179179','root179',1,'2018-04-12 12:16:32.265401','/static/public/pics/user.png','1'),(180,'root180','123467','1',23,'root180','80180180180','root180',1,'2018-04-12 12:16:32.269161','/static/public/pics/user.png','1'),(181,'root181','123467','1',23,'root181','81181181181','root181',1,'2018-04-12 12:16:32.271522','/static/public/pics/user.png','1'),(182,'root182','123467','1',23,'root182','82182182182','root182',1,'2018-04-12 12:16:32.274826','/static/public/pics/user.png','1'),(183,'root183','123467','1',23,'root183','83183183183','root183',1,'2018-04-12 12:16:32.276933','/static/public/pics/user.png','1'),(184,'root184','123467','1',23,'root184','84184184184','root184',1,'2018-04-12 12:16:32.278960','/static/public/pics/user.png','1'),(185,'root185','123467','1',23,'root185','85185185185','root185',1,'2018-04-12 12:16:32.282948','/static/public/pics/user.png','1'),(186,'root186','123467','1',23,'root186','86186186186','root186',1,'2018-04-12 12:16:32.286033','/static/public/pics/user.png','1'),(187,'root187','123467','1',23,'root187','87187187187','root187',1,'2018-04-12 12:16:32.288919','/static/public/pics/user.png','1'),(188,'root188','123467','1',23,'root188','88188188188','root188',1,'2018-04-12 12:16:32.291901','/static/public/pics/user.png','1'),(189,'root189','123467','1',23,'root189','89189189189','root189',1,'2018-04-12 12:16:32.293518','/static/public/pics/user.png','1'),(190,'root190','123467','1',23,'root190','90190190190','root190',1,'2018-04-12 12:16:32.298334','/static/public/pics/user.png','1'),(191,'root191','123467','1',23,'root191','91191191191','root191',1,'2018-04-12 12:16:32.301021','/static/public/pics/user.png','1'),(192,'root192','123467','1',23,'root192','92192192192','root192',1,'2018-04-12 12:16:32.303975','/static/public/pics/user.png','1'),(193,'root193','123467','1',23,'root193','93193193193','root193',1,'2018-04-12 12:16:32.308385','/static/public/pics/user.png','1'),(194,'root194','123467','1',23,'root194','94194194194','root194',1,'2018-04-12 12:16:32.310562','/static/public/pics/user.png','1'),(195,'root195','123467','1',23,'root195','95195195195','root195',1,'2018-04-12 12:16:32.314941','/static/public/pics/user.png','1'),(196,'root196','123467','1',23,'root196','96196196196','root196',1,'2018-04-12 12:16:32.316819','/static/public/pics/user.png','1'),(197,'root197','123467','1',23,'root197','97197197197','root197',1,'2018-04-12 12:16:32.318614','/static/public/pics/user.png','1'),(198,'root198','123467','1',23,'root198','98198198198','root198',1,'2018-04-12 12:16:32.320533','/static/public/pics/user.png','1'),(199,'root199','123467','1',1,'root199','99199199199','root199',1,'2018-04-12 12:16:32.323687','/static/public/pics/user.png','1'),(200,'root200','123467','1',1,'root200','200200200','root200',1,'2018-04-12 12:16:32.328574','/static/public/pics/user.png','1'),(201,'root201','123467','1',1,'root201','1201201201','root201',1,'2018-04-12 12:16:32.334155','/static/public/pics/user.png','1'),(202,'root202','123467','1',1,'root202','2202202202','root202',1,'2018-04-12 12:16:32.345463','/static/public/pics/user.png','1'),(203,'root203','123467','1',1,'root203','3203203203','root203',1,'2018-04-12 12:16:32.351668','/static/public/pics/user.png','1'),(204,'root204','123467','1',1,'root204','4204204204','root204',1,'2018-04-12 12:16:32.360234','/static/public/pics/user.png','1'),(205,'root205','123467','1',1,'root205','5205205205','root205',1,'2018-04-12 12:16:32.365245','/static/public/pics/user.png','1'),(206,'root206','123467','1',1,'root206','6206206206','root206',1,'2018-04-12 12:16:32.370173','/static/public/pics/user.png','1'),(207,'root207','123467','1',1,'root207','7207207207','root207',1,'2018-04-12 12:16:32.372748','/static/public/pics/user.png','1'),(208,'root208','123467','1',1,'root208','8208208208','root208',1,'2018-04-12 12:16:32.382011','/static/public/pics/user.png','1'),(209,'root209','123467','1',1,'root209','9209209209','root209',1,'2018-04-12 12:16:32.385668','/static/public/pics/user.png','1'),(210,'root210','123467','1',1,'root210','10210210210','root210',1,'2018-04-12 12:16:32.387554','/static/public/pics/user.png','1'),(211,'root211','123467','1',1,'root211','11211211211','root211',1,'2018-04-12 12:16:32.394039','/static/public/pics/user.png','1'),(212,'root212','123467','1',1,'root212','12212212212','root212',1,'2018-04-12 12:16:32.398026','/static/public/pics/user.png','1'),(213,'root213','123467','1',1,'root213','13213213213','root213',1,'2018-04-12 12:16:32.401066','/static/public/pics/user.png','1'),(214,'root214','123467','1',1,'root214','14214214214','root214',1,'2018-04-12 12:16:32.402645','/static/public/pics/user.png','1'),(215,'root215','123467','1',1,'root215','15215215215','root215',1,'2018-04-12 12:16:32.404071','/static/public/pics/user.png','1'),(216,'root216','123467','1',1,'root216','16216216216','root216',1,'2018-04-12 12:16:32.406872','/static/public/pics/user.png','1'),(217,'root217','123467','1',1,'root217','17217217217','root217',1,'2018-04-12 12:16:32.416845','/static/public/pics/user.png','1'),(218,'root218','123467','1',1,'root218','18218218218','root218',1,'2018-04-12 12:16:32.427662','/static/public/pics/user.png','1'),(219,'root219','123467','1',1,'root219','19219219219','root219',1,'2018-04-12 12:16:32.431149','/static/public/pics/user.png','1'),(220,'root220','123467','1',1,'root220','20220220220','root220',1,'2018-04-12 12:16:32.435022','/static/public/pics/user.png','1'),(221,'root221','123467','1',1,'root221','21221221221','root221',1,'2018-04-12 12:16:32.437348','/static/public/pics/user.png','1'),(222,'root222','123467','1',1,'root222','22222222222','root222',1,'2018-04-12 12:16:32.443060','/static/public/pics/user.png','1'),(223,'root223','123467','1',1,'root223','23223223223','root223',1,'2018-04-12 12:16:32.447047','/static/public/pics/user.png','1'),(224,'root224','123467','1',1,'root224','24224224224','root224',1,'2018-04-12 12:16:32.450218','/static/public/pics/user.png','1'),(225,'root225','123467','1',1,'root225','25225225225','root225',1,'2018-04-12 12:16:32.452738','/static/public/pics/user.png','1'),(226,'root226','123467','1',1,'root226','26226226226','root226',1,'2018-04-12 12:16:32.454181','/static/public/pics/user.png','1'),(227,'root227','123467','1',1,'root227','27227227227','root227',1,'2018-04-12 12:16:32.456517','/static/public/pics/user.png','1'),(228,'root228','123467','1',1,'root228','28228228228','root228',1,'2018-04-12 12:16:32.458444','/static/public/pics/user.png','1'),(229,'root229','123467','1',1,'root229','29229229229','root229',1,'2018-04-12 12:16:32.461012','/static/public/pics/user.png','1'),(230,'root230','123467','1',1,'root230','30230230230','root230',1,'2018-04-12 12:16:32.466781','/static/public/pics/user.png','1'),(231,'root231','123467','1',1,'root231','31231231231','root231',1,'2018-04-12 12:16:32.471942','/static/public/pics/user.png','1'),(232,'root232','123467','1',1,'root232','32232232232','root232',1,'2018-04-12 12:16:32.474882','/static/public/pics/user.png','1'),(233,'root233','123467','1',1,'root233','33233233233','root233',1,'2018-04-12 12:16:32.477241','/static/public/pics/user.png','1'),(234,'123123','pbkdf2_sha256$36000$gqlnaqQE86gY$HE6CTPbph1b/u7xQSA5wVLCqfdV0GH8mGN+eeEWst/s=','1',123123,'123123','1231231231','123123123@qq.com',1,'2018-04-12 16:04:34.271153','/static/public/pics/123123+1523549074.262149.jpg','1'),(235,'zsy123','pbkdf2_sha256$36000$i0WCUe0YaNHI$DmrJMteIWE2O1OeOI87YCmNK41/4+KZeyVMMpp9Iotg=','1',23,'178899102@qq.com','178899102','178899102@qq.com',1,'2018-04-13 07:07:35.436973','/static/public/pics/zsy123+1523603255.428947.jpg','1'),(236,'zsylovesxx','pbkdf2_sha256$36000$eNpPqcNvXaBW$l04FDaVXxu39gnbbG/MYnar11QA9YOySMehRqbh68ro=','1',12,'123123','1231231231','123123123@qq.com',1,'2018-04-13 07:09:51.777093','/static/public/pics/zsylovesxx+1523603391.7735975.jpg','1'),(241,'hqzsy','pbkdf2_sha256$36000$TAspPDMff2S3$5LM80n7mKw40gF7dOCx1CKxd5QdhyQtuPKQ/2PiSaAQ=','1',12,'17466666@163.com','17466666','17466666@163.com',1,'2018-04-14 07:28:11.161083','/static/public/pics/hqzsy+1523690891.1511753.jpg','1'),(242,'admin','pbkdf2_sha256$36000$9cH8sUaGJIz0$HNsanppBZvpgvZRQvkHhUhMfVfCltYNYCZYTp3FaAxE=','0',23,'123456','17888888','admin@password.com',2,'2018-04-15 04:10:16.708882','/static/public/pics/admin+1523768285.717566.jpg','1'),(243,'jainling','pbkdf2_sha256$36000$VnlZLjCCGva2$YOtyCxHqzNs4+E6KeLJsjB3YIqfQ2TQpusi1/1uC+x0=','1',123,'132123123','123123123','123132@qq.com',0,'2018-04-16 00:36:13.276888','/static/public/pics/jainling+1523838973.2754033.jpg','1'),(244,'12312312123123','pbkdf2_sha256$36000$54CISXRuenj7$zemn9GNxFJiOgelT5M95JOMgeO9NGlwRWmbai3bkFjo=','1',12,'123123','1231231231','123123123@qq.com',1,'2018-04-19 04:38:59.582481','/static/public/pics/12312312123123+1524112739.58139.jpg','1');
/*!40000 ALTER TABLE `myadmin_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21 22:01:06
